public class camel
{
    public static void main(String[] args)
    {
        System.out.println(" __");
        System.out.println("/ \"\\");
        System.out.println("\\__ \\       ___      ___");
        System.out.println("   \\ \\     /   \\    /   \\");
        System.out.println("    \\ \\___/     \\__/     \\_______");
        System.out.println("     \\_                        \\ \\");
        System.out.println("       |                        | \\");
        System.out.println("        \\ ___   _______  ___   /   \\_");
        System.out.println("        / /  | |      / /   | |");
        System.out.println("       / /   | |     / /    | |");
        System.out.println("      / /    ( |     / /    ( |");
        System.out.println("      | |     | |    | |    | |");
        System.out.println("      | |     | |    | |    | |");
        System.out.print("      /_/     /_/    /_/    /_/");
    }
}
